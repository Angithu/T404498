﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DevExpress.Web.Mvc;

namespace T404498 {
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GridViewPartial()
        {
            return PartialView(BatchEditRepository.GridData);
        }

        public ActionResult BatchUpdatePartial(MVCxGridViewBatchUpdateValues<GridDataItem, int> batchValues)
        {
            foreach (var item in batchValues.Insert)
            {
                if (batchValues.IsValid(item) && !IsDuplicatied(item, batchValues))
                    BatchEditRepository.InsertNewItem(item, batchValues);
                else
                    batchValues.SetErrorText(item, "Correct validation errors and double-check for duplicated values");
            }
            foreach (var item in batchValues.Update)
            {
                if (batchValues.IsValid(item) && !IsDuplicatied(item, batchValues))
                    BatchEditRepository.UpdateItem(item, batchValues);
                else
                    batchValues.SetErrorText(item, "Correct validation errors");
            }
            foreach (var itemKey in batchValues.DeleteKeys)
            {
                BatchEditRepository.DeleteItem(itemKey, batchValues);
            }

            return PartialView("GridViewPartial", BatchEditRepository.GridData);
        }

        private bool IsDuplicatied(GridDataItem item, MVCxGridViewBatchUpdateValues<GridDataItem, int> batchValues)
        {
            if (BatchEditRepository.GridData.Where(x => x.C3 == item.C3 && x.Id != item.Id).Count() > 0){
                batchValues.SetErrorText(item, "Values are not unqique");
                return true;
            }
            else
                return false;
            
       
        }
    }
}