﻿using System;
using System.Collections.Generic;
using System.Linq;

public partial class _Default : System.Web.UI.Page
{
    protected const int itemsCount = 5;

    public List<Item> Items
    {
        get
        {
            if (Session["Items"] == null)
                Session["Items"] = new List<Item>();

            return (List<Item>)Session["Items"];
        }
    }

    protected void FillItems()
    {
        Items.Clear();

        for (int i = 1; i <= itemsCount; i++)
        {
            if (i == 1)
                Items.Add(new Item(i, null));
            else
                Items.Add(new Item(i, "Item" + i));
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["Items"] = null;
            FillItems();
        }

        ASPxGridView.DataSource = Items;
        ASPxGridView.DataBind();
    }

    protected void ASPxGridView_CommandButtonInitialize(object sender, DevExpress.Web.ASPxGridViewCommandButtonEventArgs e)
    {
        if (e.ButtonType == DevExpress.Web.ColumnCommandButtonType.Edit)
        {
            object name = ASPxGridView.GetRowValues(e.VisibleIndex, "Name");
            e.Visible = (name != null);
        }
    }
}